package io.github.team6ENG.EscapeUni;

import com.badlogic.gdx.Graphics;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;



class GameScreenTest{
    //Testing Positive and Negative Events
    @Test
    void HeartIsWorkingTest() {
        Main mockGame = mock(Main.class);
       // AudioManager mockAudio = mock(AudioManager.class);
        GameScreen mockGameScreen = new GameScreen(mockGame);
        Collectable mockCollectable = mock(Collectable.class);

        mockGameScreen.healthSystem.takeDamage(30); //damage health so the heart will heal
        mockGameScreen.items.put("healthBoost", mockCollectable);
        float delta = 0.01f;
        mockGameScreen.update(delta);

        assertEquals(95f, mockGameScreen.healthSystem.getHealth());
    }

    @Test
    void ShieldIsWorkingTest(){
        Main mockGame = mock(Main.class);
        GameScreen mockGameScreen = new GameScreen(mockGame);
        Collectable mockCollectable = mock(Collectable.class);

        mockGameScreen.items.put("shield", mockCollectable);

        float delta =0.01f;
        mockGameScreen.update(delta);

        assertTrue(mockGameScreen.healthSystem.isInvincible());
        assertTrue(mockGameScreen.hasShield);

        mockGameScreen.healthSystem.takeDamage(10);
        assertEquals(100f, mockGameScreen.healthSystem.getHealth()); //Health should not be effective when shield is active
    }

    @Test
    void GooseFoodTest(){
        Main mockGame = mock(Main.class);
        GameScreen mockGameScreen = new GameScreen(mockGame);
        Collectable mockCollectable = mock(Collectable.class);

        mockGameScreen.items.put("gooseFood", mockCollectable);

        float delta =0.01f;
        mockGameScreen.update(delta);

        assertTrue(mockGameScreen.hasGooseFood);
    }

    @Test
    //Note change foodPoisoned attribute to public
    void RottenPizzaTest(){
        Main mockGame = mock(Main.class);
        GameScreen mockGameScreen = new GameScreen(mockGame);
        Collectable mockCollectable = mock(Collectable.class);

        mockGameScreen.items.put("rottenPizza", mockCollectable);

        float delta =0.016f;
        mockGameScreen.update(delta);

        assertTrue(mockGameScreen.foodPoisoned);

    }

    @Test
    //Note change beerActive and isScreenFlipped attributed to public
    void beerTest(){
        Main mockGame = mock(Main.class);
        GameScreen mockGameScreen = new GameScreen(mockGame);
        Collectable mockCollectable = mock(Collectable.class);

        mockGameScreen.items.put("beer", mockCollectable);

        float delta =0.01f;
        mockGameScreen.update(delta);

        assertTrue(mockGameScreen.beerActive);
        assertTrue(mockGameScreen.isScreenFlipped);
    }

    @Test
    void AirhornTest(){
        Main mockGame = mock(Main.class);
        GameScreen mockGameScreen = new GameScreen(mockGame);
        Collectable mockCollectable = mock(Collectable.class);

        mockGameScreen.items.put("airHorn", mockCollectable);

        float delta =0.01f;
        mockGameScreen.update(delta);

        assertTrue(mockGameScreen.airHornActive);

    }

}
