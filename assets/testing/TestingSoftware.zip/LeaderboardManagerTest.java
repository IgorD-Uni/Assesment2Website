package io.github.team6ENG.EscapeUni;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LeaderboardManagerTest {

    @Test
    void getInstance() {
    }

    @Test
    void addScore() {
    }

    @Test
    void getTop() {
    }

    @Test
    void getAll() {
    }

    @Test
    void setMaxEntries() {
    }
}