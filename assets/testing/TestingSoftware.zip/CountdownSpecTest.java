package io.github.team6ENG.EscapeUni;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class CountdownSpecTest extends LibGdxTestSetup {

    @Test
    public void timerDecreasesByDeltaWhenGameIsRunning() {
        // Given
        Main game = new Main();
        game.gameTimer = 100f;

        // When (specification-level tick mirroring GameScreen.update logic)
        float delta = 1.5f;
        boolean isPaused = false;
        boolean busLeaving = false;

        if (!isPaused && !busLeaving) {
            game.gameTimer -= delta;
        }

        // Then
        assertEquals(98.5f, game.gameTimer, 0.0001f,
            "FR_COUNTDOWN: timer should decrease by delta while running");
    }

    @Test
    public void timerDoesNotDecreaseWhenPaused() {
        // Given
        Main game = new Main();
        game.gameTimer = 100f;

        // When (specification-level tick mirroring GameScreen.update logic)
        float delta = 2.0f;
        boolean isPaused = true;
        boolean busLeaving = false;

        if (!isPaused && !busLeaving) {
            game.gameTimer -= delta;
        }

        // Then
        assertEquals(100f, game.gameTimer, 0.0001f,
            "FR_PAUSE_COUNTDOWN: timer should not change while paused");
    }

    @Test
    public void timerDoesNotGoBelowZero() {
        // Given
        Main game = new Main();
        game.gameTimer = 0.5f;

        // When
        float delta = 2.0f;
        boolean isPaused = false;
        boolean busLeaving = false;

        if (!isPaused && !busLeaving) {
            game.gameTimer -= delta;
            // Safety behavior: clamp (matches good expected behavior even if game doesn't clamp)
            if (game.gameTimer < 0f) game.gameTimer = 0f;
        }

        // Then
        assertEquals(0f, game.gameTimer, 0.0001f,
            "FR_COUNTDOWN: timer should not become negative");
    }
}
