package io.github.team6ENG.EscapeUni;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class HealthSystemTest {


    @Test
    void takeDamageTest() {
        HealthSystem mockHealthSystem = new HealthSystem();
        mockHealthSystem.takeDamage(50f);
        assertEquals(50f, mockHealthSystem.getHealth());
    }

    @Test
    void takeDamageNegative(){
        HealthSystem mockHealthSystem = new HealthSystem();
        mockHealthSystem.takeDamage(500f);
        assertEquals(0f, mockHealthSystem.getHealth());
    }

    @Test
    void heal() {
        HealthSystem mockHealthSystem = new HealthSystem();
        mockHealthSystem.takeDamage(70f);
        mockHealthSystem.heal(40f);
        assertEquals(70f, mockHealthSystem.getHealth());
    }

    @Test
    void healExceed() {
        HealthSystem mockHealthSystem = new HealthSystem();
        mockHealthSystem.takeDamage(10f);
        mockHealthSystem.heal(60f);
        assertEquals(100f, mockHealthSystem.getHealth());
    }

    @Test
    void InitialInvincible() {
        HealthSystem mockHealthSystem = new HealthSystem();
        assertFalse(mockHealthSystem.isInvincible());
    }


    @Test
    void IsDeadTrue() {
        HealthSystem mockHealthSystem = new HealthSystem();
        mockHealthSystem.takeDamage(200f);
        assertTrue(mockHealthSystem.isDead());
    }

    @Test
    void IsDeadFalse(){
        HealthSystem mockHealthSystem = new HealthSystem();
        assertFalse(mockHealthSystem.isDead());
    }
}