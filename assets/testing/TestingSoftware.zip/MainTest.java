package io.github.team6ENG.EscapeUni;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MainTest {

    @Test
    void TimerTest(){
        Main mockGame = new Main();

        assertEquals(300, mockGame.gameTimer);
    }

    @Test
    void ResetTimerTest(){
        Main mockGame = new Main();

        //setting the timer to a different time to check reset function
        mockGame.gameTimer.set() = 200;

        //gameTimer doesn't have a set function
        mockGame.resetGame();

        //After resetting the game the timer should be 300 seconds
        assertEquals(300, mockGame.gameTimer);
    }

    @Test
    void InitialScoreTest(){
        //Player should start with 300 points
        Main mockGame = new Main();
        assertEquals(300, mockGame.score);
    }

}