package io.github.team6ENG.EscapeUni;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ScoreSpecTest extends LibGdxTestSetup {

    @Test
    public void scoreDecreasesByDeltaAsTimePasses() {
        // Given
        Main game = new Main();
        game.score = 300f;

        // When (mirrors GameScreen.update: game.score -= delta)
        float delta = 2.5f;
        boolean isPaused = false;
        boolean busLeaving = false;

        if (!isPaused && !busLeaving) {
            game.score -= delta;
        }

        // Then
        assertEquals(297.5f, game.score, 0.0001f,
            "FR_SCORE: score should decrease as time passes");
    }

    @Test
    public void scoreIncreasesAfterAnInteractionAward() {
        // Given
        Main game = new Main();
        game.score = 200f;

        // When (mirrors GameScreen.update: score bonus on interaction, e.g. +100)
        float interactionBonus = 100f;
        game.score += interactionBonus;

        // Then
        assertEquals(300f, game.score, 0.0001f,
            "FR_SCORE: score should increase after completing interactions");
    }

    @Test
    public void scoreDoesNotGoBelowZero() {
        // Given
        Main game = new Main();
        game.score = 1.0f;

        // When
        float delta = 5.0f;
        boolean isPaused = false;
        boolean busLeaving = false;

        if (!isPaused && !busLeaving) {
            game.score -= delta;
            if (game.score < 0f) game.score = 0f; // expected safety behavior
        }

        // Then
        assertEquals(0f, game.score, 0.0001f,
            "FR_SCORE: score should not become negative");
    }
}
